#include <stdio.h>

int main(int argc, char* argv[])
{

 printf("argc = %d\n",argc);
 
 printf(" %s\n",argv[0]);
 
 return 1;
 
}
